package com.spring.example.bean;

public class Files {

}
