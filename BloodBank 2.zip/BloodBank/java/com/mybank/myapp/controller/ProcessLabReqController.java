package com.mybank.myapp.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.TestDetails;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.DonationDetailsService;
import com.mybank.myapp.service.InventoryService;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.TestDetailsService;
import com.mybank.myapp.service.UserAccountService;

public class ProcessLabReqController extends SimpleFormController{

	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	DonationDetailsService donationDetailsService;
	TestDetailsService testDetailsService;
	InventoryService inventoryService;
	
	
	public ProcessLabReqController()
	{
		
	}
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("labtechnician") &&user.getStatus().equals("Active"))
		 {      
		System.out.println("Welcom to assigning");
		List<TestDetails> testdetlist=testDetailsService.getTestDetailsList();
		String testid=request.getParameter("testid");
		int testdetailsid=Integer.parseInt(testid);
		TestDetails testdetail=testDetailsService.getTestDetails(testdetailsid);
		model.put("testdetlist", testdetlist);
		model.put("user",user);
		model.put("testdetail", testdetail);
		session.setAttribute("testdetail", testdetail);
		session.setAttribute("model", model);
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
		
		User user=(User)session.getAttribute("user");
		if(user!=null &&  user.getRole().getRole().equals("labtechnician")&&user.getStatus().equals("Active"))
		{
			TestDetails testdetail=(TestDetails)session.getAttribute("testdetail");
			System.out.println("Welcom to succesview");
			
			
						
			//testdetail.setTestdate(request.getParameter("testdate"));
			List<TestDetails> testdetlist=testDetailsService.getTestDetailsList();
			testdetail.setTestedby(user.getUsername());
			System.out.println(testdetail+"DONATIONDETAILS");
				testdetail.setTestdate(request.getParameter("testdate"));
			testdetail.setTestresult(request.getParameter("testresult"));
			testDetailsService.updatetestDetails(testdetail);
			System.out.println("Mahesh");
			/*if(testdetail.getTestresult().equalsIgnoreCase("Usable"))
			{
				
				System.out.println("I am Inside");
				
				String bloodtype=testdetail.getDonationdetails().getBloodproduct();
				System.out.println("I am Inside1"+bloodtype);
				
				Schedule temp=testdetail.getDonationdetails().getSchedule();
				String bg=temp.getDonor().getBloodgrp();
				System.out.println("I am Inside2");
				*/
				/*if(bloodtype.equalsIgnoreCase("WBC"))
				{
					
					System.out.println("I am wbc");
					if(bg.equalsIgnoreCase("A+"))
					{
						System.out.println("I am Inside3");
						
						inv=inventoryService.getInventory(1);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="A-")
					{
						inv=inventoryService.getInventory(2);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B+")
					{
						inv=inventoryService.getInventory(3);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B-")
					{
						inv=inventoryService.getInventory(4);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O+")
					{
						inv=inventoryService.getInventory(5);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O-")
					{
						inv=inventoryService.getInventory(6);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB+")
					{
						inv=inventoryService.getInventory(7);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB-")
					{
						inv=inventoryService.getInventory(8);
						inv.setWbcquantity(inv.getWbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					
					
				}
				else if(bloodtype.equalsIgnoreCase("RBC"))
				{
					if(bg=="A+")
					{
						System.out.println("I am Inside3");
						
						inv=inventoryService.getInventory(1);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="A-")
					{
						inv=inventoryService.getInventory(2);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B+")
					{
						inv=inventoryService.getInventory(3);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B-")
					{
						inv=inventoryService.getInventory(4);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O+")
					{
						inv=inventoryService.getInventory(5);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O-")
					{
						inv=inventoryService.getInventory(6);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB+")
					{
						inv=inventoryService.getInventory(7);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB-")
					{
						inv=inventoryService.getInventory(8);
						inv.setRbcquantity(inv.getRbcquantity()+1);
						inventoryService.updateInventory(inv);
					}
				}
				else if(bloodtype.equalsIgnoreCase("Platelets"))
				{
					if(bg=="A+")
					{
						System.out.println("I am Inside3");
						
						inv=inventoryService.getInventory(1);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="A-")
					{
						inv=inventoryService.getInventory(2);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B+")
					{
						inv=inventoryService.getInventory(3);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B-")
					{
						inv=inventoryService.getInventory(4);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O+")
					{
						inv=inventoryService.getInventory(5);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O-")
					{
						inv=inventoryService.getInventory(6);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB+")
					{
						inv=inventoryService.getInventory(7);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB-")
					{
						inv=inventoryService.getInventory(8);
						inv.setPlateletsquantity(inv.getPlateletsquantity()+1);
						inventoryService.updateInventory(inv);
					}
				}
				
				else if(bloodtype.equalsIgnoreCase("WholeBlood"))
				{
					if(bg=="A+")
					{
						System.out.println("I am Inside3");
						
						inv=inventoryService.getInventory(1);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="A-")
					{
						inv=inventoryService.getInventory(2);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B+")
					{
						inv=inventoryService.getInventory(3);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="B-")
					{
						inv=inventoryService.getInventory(4);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O+")
					{
						inv=inventoryService.getInventory(5);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="O-")
					{
						inv=inventoryService.getInventory(6);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB+")
					{
						inv=inventoryService.getInventory(7);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
					else if(bg=="AB-")
					{
						inv=inventoryService.getInventory(8);
						inv.setWholebloodquantity(inv.getWholebloodquantity()+1);
						inventoryService.updateInventory(inv);
					}
				}
			}*/
			
			return new ModelAndView(getSuccessView(), "user", user); 
			
		}
	return null;
		
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}
	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	public ScheduleService getScheduleService() {
		return scheduleService;
	}
	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	public DonationDetailsService getDonationDetailsService() {
		return donationDetailsService;
	}
	public void setDonationDetailsService(
			DonationDetailsService donationDetailsService) {
		this.donationDetailsService = donationDetailsService;
	}
	public TestDetailsService getTestDetailsService() {
		return testDetailsService;
	}
	public void setTestDetailsService(TestDetailsService testDetailsService) {
		this.testDetailsService = testDetailsService;
	}
	public InventoryService getInventoryService() {
		return inventoryService;
	}
	public void setInventoryService(InventoryService inventoryService) {
		this.inventoryService = inventoryService;
	}
	
	

}

