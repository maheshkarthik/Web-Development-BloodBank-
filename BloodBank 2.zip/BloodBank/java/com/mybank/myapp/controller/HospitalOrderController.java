package com.mybank.myapp.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.HosOrder;
import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.TestDetails;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.HospitalService;


public class HospitalOrderController extends SimpleFormController {
	
	HttpSession session;
	HospitalService hospitalService;
	
	
	
	public HospitalOrderController()
	{
		
	}
	
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("hadmin") &&user.getStatus().equals("Active"))
		 {      
		System.out.println("Welcom to assigning");
		
		model.put("user",user);
		
		
		session.setAttribute("model", model);
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}

	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		
		session = request.getSession(true);
		 
		 Map<String, Object> model = new HashMap<String, Object>();

		 		User user=(User)session.getAttribute("user");
		 		if(user!=null &&  user.getRole().getRole().equals("hadmin")&&user.getStatus().equals("Active"))
		 		{
		 			System.out.println("i am here");
		 			System.out.println((ArrayList<HosRequest>) session.getAttribute("reqarray"));
		 			Organization nearestorg=hospitalService.getnearestorg(user.getOrg().getZipcode(),(ArrayList<HosRequest>) session.getAttribute("reqarray"));
	          System.out.println(nearestorg);
		 			if(nearestorg!=null)
	           {
		 				int q=0;
	        	  HosOrder horder=(HosOrder)command;
	        	  horder.setBloodbankname(nearestorg.getOrgname());
	        	  horder.setHospitalname(user.getOrg().getOrgname());
	        	  horder.setOrderstatus("Completed");
	        	  Calendar cal = Calendar.getInstance();
	        	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        	     horder.setOrderdate(sdf.format(cal.getTime()));
	        	
	        	  hospitalService.addHosOrder(horder);
	        	  HosOrder ho=hospitalService.getHosOrder(horder.getOrderid());
	        	  System.out.println(ho+"ko");
	        	  
	        	  
	        	ArrayList<HosRequest> reqlist=(ArrayList<HosRequest>) session.getAttribute("reqarray");
	           	List<HosRequest> hsreqlist=hospitalService.getHosRequestList();
	        	
	        		for(HosRequest hsr:hsreqlist)
	        		{
	        			
	        		if(hsr.getHosorder()== 0)
	        		{
	        			System.out.println(hsr.getProducttype());
	        			if(hsr.getProducttype().equalsIgnoreCase("WBC")||hsr.getProducttype().equalsIgnoreCase("RBC"))
	        			{
	        				    			q+=hsr.getQuantity()*15;
	        			}
	        			else if(hsr.getProducttype().equalsIgnoreCase("Platelets"))
	        				{
	        				q+=hsr.getQuantity()*10;
	        				}
	        			else if(hsr.getProducttype().equalsIgnoreCase("WholeBlood"))
	        			{
	        				q+=hsr.getQuantity()*5;
	        			}
	        				
	        	System.out.println("spiderman coming");
	        		hsr.setHosorder(horder.getOrderid());
	        		System.out.println(horder.getOrderid()+"wowooooooowwwww");
	        		hospitalService.updateHosRequest(hsr);
	        		System.out.println("dai spiderman");
	        		}
	        		
	        	  }
	        		System.out.println("amount"+q);
	        		horder.setAmount(q);
	        		hospitalService.updateHosOrder(horder);

}
	           else
	           {
	        	   System.out.println("spiderman going");
	        	   List<HosRequest> hsreqlist=hospitalService.getHosRequestList();
	        	   for(HosRequest hsr:hsreqlist)
	        		{
	        		   if(hsr.getHosorder()==0)
	        		   {
	        			   hospitalService.deleteHosRequest(hsr);
	        			   
	        		}
	        		}
	        	   return new ModelAndView("googlemaps","user", user);
	           }
		 		 		 		
		 		}
		 		return new ModelAndView(getSuccessView(), "user", user);     
}

	public HospitalService getHospitalService() {
		return hospitalService;
	}

	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}
	
	
}
