package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.DonationDetails;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.DonationDetailsService;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.UserAccountService;

public class CreateDonationDetailsController extends SimpleFormController {
	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	DonationDetailsService donationDetailsService;
	
	public CreateDonationDetailsController()
	{
		
	}	
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("receptionist") &&user.getStatus().equals("Active"))
		 {      
		System.out.println("Welcom to assigning");
		List nurselist=(List)session.getAttribute("nurselist");
		String sid=request.getParameter("sid");
		int scid=Integer.parseInt(sid);
		Schedule schedule=scheduleService.getSchedule(scid);
		model.put("nurselist", nurselist);
		model.put("user",user);
		model.put("schedule", schedule);
		session.setAttribute("schedule", schedule);
		session.setAttribute("model", model);
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
		 Map<String, Object> model = (Map<String, Object>) session.getAttribute("model");
		User user=(User)session.getAttribute("user");
		if(user!=null&&  user.getRole().getRole().equals("receptionist")&&user.getStatus().equals("Active"))
		{
			DonationDetails dondetails=(DonationDetails) command;
			
			String nur=request.getParameter("nurse");
			System.out.println(nur+"nurse");
			int nurseid=Integer.parseInt(nur);
			Schedule schedule=(Schedule)session.getAttribute("schedule");
			System.out.println(schedule);
			
			User nurse=userAccountService.getUser(nurseid);
			
			dondetails.setExtractedby(nurse.getUsername());
			dondetails.setDonationdate(schedule.getScheduledate());
			dondetails.setSchedule(schedule);
			dondetails.setDonationstatus("Pending");
			List<DonationDetails> dondetlist=donationDetailsService.getDonationDetailsList();
			if(donationDetailsService.confirmappointment(dondetlist,dondetails)!=false)
			{
			System.out.println(dondetails+"DONATIONDETAILS");
			donationDetailsService.addDonationDetails(dondetails);
			schedule.setAssignedstatus("Assigned");
			scheduleService.updateSchedule(schedule);
			//session.setAttribute("schedule", schedule)
			return new ModelAndView(getSuccessView(), "user", user); 
			}
			else
			{
				return new ModelAndView("scheduleBooked","schedule",schedule);
			}
		}
	return null;
		
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}
	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	public ScheduleService getScheduleService() {
		return scheduleService;
	}
	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	public DonationDetailsService getDonationDetailsService() {
		return donationDetailsService;
	}
	public void setDonationDetailsService(
			DonationDetailsService donationDetailsService) {
		this.donationDetailsService = donationDetailsService;
	}
	
	
}
