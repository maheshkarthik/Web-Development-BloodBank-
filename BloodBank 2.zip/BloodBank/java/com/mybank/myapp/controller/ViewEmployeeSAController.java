package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.UserAccountService;

public class ViewEmployeeSAController extends SimpleFormController{

	 UserAccountService userAccountService;
	    HttpSession session;
	
	public ViewEmployeeSAController()	
	{
		
	}
	
	 protected ModelAndView handleRequestInternal(HttpServletRequest request,
          HttpServletResponse response) throws Exception {

		 	session = request.getSession(true);
		 	 Map<String, Object> model = new HashMap<String, Object>();
			 User user=(User)session.getAttribute("user");
			 if(user!=null&&  user.getRole().getRole().equals("superadmin")&&user.getStatus().equals("Active"))
			 {
				 System.out.println("inside view");
				 String empid=request.getParameter("empid");
					int id=Integer.parseInt(empid);
					User emp=userAccountService.getUser(id);
					model.put("emp",emp);
			           return new ModelAndView("viewEmp", "model", model);
				 
			 }
			 else
			 {
				 return new ModelAndView("invalidLogin");
			 }

}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	 
	 
}

