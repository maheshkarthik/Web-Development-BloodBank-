package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.InventoryService;
import com.mybank.myapp.service.UserAccountService;

public class MailController extends SimpleFormController {
	
	HttpSession session;
	InventoryService inventoryService;
	UserAccountService userAccountService;
	private static final String SMTP_HOST_NAME = "smtp.gmail.com";
	private static final String SMTP_PORT = "465";
	private static final String emailMsgTxt = "Test Message Contents";
	private static final String emailSubjectTxt = "A test from gmail";
	private static final String emailFromAddress = "mahesh.karthikd@gmail.com";
	private static final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
	private static final String[] sendTo = {"mahesh_matitude@yahoo.com"};
	
	public MailController() {
		// TODO Auto-generated constructor stub
	}
	
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("superadmin") &&user.getStatus().equals("Active"))
		 {      
		
		model.put("user",user);
		session.setAttribute("model", model);
		
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
		
		
		User user=(User)session.getAttribute("user");
		if(user!=null &&  user.getRole().getRole().equals("superadmin")&&user.getStatus().equals("Active"))
		{
			final String emailFromAddress = "mahesh.karthikd@gmail.com";
			
			List<Donor> donlist=userAccountService.getDonorList();
			String[] sendTo=new String[donlist.size()];
			int i=0;
			for(Donor d:donlist)
			{
				sendTo[i++]=d.getEmail();
	              if(i==sendTo.length)
	                  break;
			}
			String emailSubjectTxt= request.getParameter("sub");
		    String emailMsgTxt=request.getParameter("content");
		    sendSSLMessage(sendTo, emailSubjectTxt, emailMsgTxt, emailFromAddress);
			
			
			return new ModelAndView(getSuccessView(), "user", user); 
			
		}
	return null;
		
	}
	
	public void sendSSLMessage(String recipients[], String subject,
			String message, String from) throws MessagingException {
			boolean debug = true;

			Properties props = new Properties();
			props.put("mail.smtp.host", SMTP_HOST_NAME);
			props.put("mail.smtp.auth", "true");
			props.put("mail.debug", "true");
			props.put("mail.smtp.port", SMTP_PORT);
			props.put("mail.smtp.socketFactory.port", SMTP_PORT);
			props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
			props.put("mail.smtp.socketFactory.fallback", "false");
            
			
			SMTPAuthenticator auth=new SMTPAuthenticator("mahesh.karthikd@gmail.com", "ganesh123");
			Session session = Session.getDefaultInstance(props,auth);
			

			session.setDebug(debug);

			Message msg = new MimeMessage(session);
			InternetAddress addressFrom = new InternetAddress(from);
			msg.setFrom(addressFrom);

			InternetAddress[] addressTo = new InternetAddress[recipients.length];
			for (int i = 0; i < recipients.length; i++) {
			addressTo[i] = new InternetAddress(recipients[i]);
			}
			msg.setRecipients(Message.RecipientType.TO, addressTo);

			// Setting the Subject and Content Type
			msg.setSubject(subject);
			msg.setContent(message, "text/plain");
			Transport.send(msg);
	}
	public InventoryService getInventoryService() {
		return inventoryService;
	}

	public void setInventoryService(InventoryService inventoryService) {
		this.inventoryService = inventoryService;
	}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	
}
