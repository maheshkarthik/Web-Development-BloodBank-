package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.RoleService;
import com.mybank.myapp.service.UserAccountService;

public class DisorDelEmployeeController extends AbstractController {
	UserAccountService userAccountService;
	
	HttpSession session;

	
	public DisorDelEmployeeController()
	{
		
	}
	
	  protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {

        session = request.getSession(true);
        Map<String, Object> model = new HashMap<String, Object>();
        
        User user=(User)session.getAttribute("user");
        if(user!=null &&  user.getRole().getRole().equals("bbadmin")&&user.getStatus().equals("Active"))
		 {      
			 String empid=request.getParameter("empid");
				int id=Integer.parseInt(empid);
				
				 String action = request.getParameter("action");
				 
				 if (action != null) {
					 if (action.equals("dis")) {
						 
						 userAccountService.disableUser(id);
						 List<User> userList = userAccountService.getUserList();
						 System.out.println(userList+"hi hi hi");
	                        model.put("userList", userList);
						 return new ModelAndView("redirect:adminhome.htm", "model", model);
						 }
					 else if (action.equals("ena")) {
						 
						 userAccountService.enableUser(id);
						 List<User> userList = userAccountService.getUserList();
						 System.out.println(userList+"oi oi oi");
	                        model.put("userList", userList);
						 return new ModelAndView("redirect:adminhome.htm", "model", model);
						 }
					 else if(action.equals("del"))
					 {
						 userAccountService.deleteUser(id);
						 List<User> userList = userAccountService.getUserList();
	                        model.put("userList", userList);
						 return new ModelAndView("redirect:adminhome.htm", "model", model);
					 }
					 
				 }
				 System.out.println("entering sys admin controller no actio attri loop");
                 List<User> userList = userAccountService.getUserList();
                 model.put("userList", userList);
                 return new ModelAndView("redirect:adminhome.htm", "model", model);
				
				
		 }
        else
        {
        	return new ModelAndView("invalidLogin");
        }
	}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	  


}
