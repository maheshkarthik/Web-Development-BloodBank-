package com.mybank.myapp.controller;

import java.awt.image.RenderedImage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jfree.data.general.DefaultPieDataset;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.HosOrder;
import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.HospitalService;
import com.mybank.myapp.service.InventoryService;
import com.mybank.myapp.service.TestDetailsService;

public class HospitalHomeController extends AbstractController {

	HttpSession session;
	InventoryService inventoryService;
	TestDetailsService  testDetailsService;
	HospitalService hospitalService;
	public HospitalHomeController()
	{
		
	}
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		 HttpSession session = request.getSession(true);
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println("outside");
		 
		 if(user!=null&&  user.getRole().getRole().equalsIgnoreCase("hadmin")&&user.getStatus().equals("Active"))
		 {
			 
			 System.out.println("hi hi hi");
			 List<HosRequest> hsreqlist=hospitalService.getHosRequestList();
			 List<HosOrder> hsordlist=hospitalService.getHosOrderList();
			 
			int inv[][]=new int[8][4];
			for(HosOrder ho:hsordlist)
			{
				if(ho.getHospitalname().equalsIgnoreCase(user.getOrg().getOrgname()))
				{
			for(HosRequest td:hsreqlist)
			{
				
						
					String bloodtype=td.getProducttype();
					System.out.println("I am Inside1"+bloodtype);
					
					String bg=td.getBloodgroup();
					int i=td.getQuantity();
					System.out.println("I am Inside2"+bg);
					
					if(bloodtype.equalsIgnoreCase("WBC"))
					{
						
						System.out.println("I am wbc");
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][0]+=i;
						}	
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][0]+=i;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][0]+=i;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][0]+=i;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][0]+=i;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][0]+=i;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][0]+=i;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][0]+=i;
						}
						
						
					}
					else if(bloodtype.equalsIgnoreCase("RBC"))
					{
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							inv[0][1]+=i;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][1]+=i;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][1]+=i;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][1]+=i;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][1]+=i;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][1]+=i;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][1]+=i;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][1]+=i;
						}
					}
					else if(bloodtype.equalsIgnoreCase("Platelets"))
					{
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][2]+=i;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][2]+=i;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][2]+=i;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][2]+=i;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][2]+=i;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][2]+=i;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][2]+=i;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][2]+=i;
						}
					}
					
					else if(bloodtype.equalsIgnoreCase("WholeBlood"))
					{
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][3]+=i;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][3]+=i;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][3]+=i;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][3]+=i;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][3]+=i;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][3]+=i;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][3]+=i;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][3]+=i;
						}
					}
					
					}
				}
			}
			
			
				model.put("user",user);
				model.put("inv", inv);
				 
	           return new ModelAndView("hospitalHomePage", "model", model);


}
		 else
		 {
			 return new ModelAndView("invalidLogin");
		 }

}
	 
	 private RenderedImage getChart(HttpServletRequest request) {
	       
	        // also you can process other parameters like width or height here
	        
	        	 DefaultPieDataset pieDataset = new DefaultPieDataset();
	            return null;
	        }
	        
	        
	public InventoryService getInventoryService() {
		return inventoryService;
	}
	public void setInventoryService(InventoryService inventoryService) {
		this.inventoryService = inventoryService;
	}
	public TestDetailsService getTestDetailsService() {
		return testDetailsService;
	}
	public void setTestDetailsService(TestDetailsService testDetailsService) {
		this.testDetailsService = testDetailsService;
	}
	public HospitalService getHospitalService() {
		return hospitalService;
	}
	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}
	
	
}
