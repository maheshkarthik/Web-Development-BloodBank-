package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.RoleService;
import com.mybank.myapp.service.UserAccountService;

public class UpdateEmployeeSAController extends SimpleFormController{

	UserAccountService userAccountService;
	OrganizationService organizationService;
	RoleService roleService;
	HttpSession session;
	    
	    public UpdateEmployeeSAController()
	    {
	    	
	    }
	    
	    public Map referenceData(HttpServletRequest request, Object object,
				Errors errors) throws Exception {
			 session = request.getSession(true);
			 Map<String, Object> model = new HashMap<String, Object>();
			 User user=(User)session.getAttribute("user");
			 System.out.println(user+"update");
			 if(user!=null &&  user.getRole().getRole().equals("superadmin")&&user.getStatus().equals("Active"))
			 {      
				 String empid=request.getParameter("empid");
					int id=Integer.parseInt(empid);
					User emp=userAccountService.getUser(id);
					System.out.println(emp+"empupdate");
					session.setAttribute("upemp", emp);
					model.put("emp",emp);
					session.setAttribute("model", model);
					System.out.println(model+"modelready");
			return model;
			 }
			 else
			 {
				 return null;
			 }
		     

		}
		
		protected ModelAndView onSubmit(HttpServletRequest request,
				HttpServletResponse response, Object command, BindException errors)
				throws Exception {
			
				
			User newemp = (User) command;
			 User user=(User)session.getAttribute("user");
			 System.out.println(user);
			 if(user!=null &&  user.getRole().getRole().equals("superadmin")&&user.getStatus().equals("Active"))
			 {
				 User upemp=(User)session.getAttribute("upemp");
		
			newemp.setUsername(upemp.getUsername());
			newemp.setPassword(upemp.getPassword());
			newemp.setEmpid(upemp.getEmpid());
			newemp.setOrg(upemp.getOrg());
			newemp.setStatus(upemp.getStatus());
			newemp.setRole(upemp.getRole());
			

			
				userAccountService.updateUser(newemp);
				
				return new ModelAndView(getSuccessView(), "user", user);
			
			 }
			 else
			 {
				 JFrame frame = new JFrame("Show Message Dialog");
					JOptionPane.showMessageDialog(frame, "You are not authorized/loggedin to view this page");
		        	return new ModelAndView("home");
			 }
		}

		public UserAccountService getUserAccountService() {
			return userAccountService;
		}

		public void setUserAccountService(UserAccountService userAccountService) {
			this.userAccountService = userAccountService;
		}

		public OrganizationService getOrganizationService() {
			return organizationService;
		}

		public void setOrganizationService(OrganizationService organizationService) {
			this.organizationService = organizationService;
		}

		public RoleService getRoleService() {
			return roleService;
		}

		public void setRoleService(RoleService roleService) {
			this.roleService = roleService;
		}
		
		
		
	}



