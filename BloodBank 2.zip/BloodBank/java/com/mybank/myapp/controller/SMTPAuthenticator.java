


package com.mybank.myapp.controller;



import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticator extends Authenticator{

    private PasswordAuthentication authentication;
    

    public SMTPAuthenticator(String username, String password)
    {
        authentication=new PasswordAuthentication(username, password);
        
    }
   
    protected PasswordAuthentication getPasswordAuthentication() {       
            return authentication;
                
    }
}
