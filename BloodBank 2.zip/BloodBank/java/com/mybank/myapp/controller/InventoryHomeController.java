package com.mybank.myapp.controller;

import java.awt.image.RenderedImage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.TestDetails;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.InventoryService;
import com.mybank.myapp.service.TestDetailsService;

public class InventoryHomeController extends AbstractController{

	HttpSession session;
	InventoryService inventoryService;
	TestDetailsService  testDetailsService;
	public InventoryHomeController()
	{
		
	}
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		 HttpSession session = request.getSession(true);
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println("outside");
		 
		 if(user!=null&&  user.getRole().getRole().equalsIgnoreCase("inventorymanager")&&user.getStatus().equals("Active"))
		 {
			 
			 System.out.println("hi hi hi");
			List<TestDetails> tdlist=testDetailsService.getTestDetailsList();
			int inv[][]=new int[8][4];
			for(TestDetails td:tdlist)
			{
				if(td.getDonationdetails().getSchedule().getOrg().getOrgid()== user.getOrg().getOrgid())
				{
					if(td.getTestresult().equalsIgnoreCase("Usable"))
					{
						
					String bloodtype=td.getDonationdetails().getBloodproduct();
					System.out.println("I am Inside1"+bloodtype);
					
					Schedule temp=td.getDonationdetails().getSchedule();
					String bg=temp.getDonor().getBloodgrp();
					System.out.println("I am Inside2"+bg);
					
					if(bloodtype.equalsIgnoreCase("WBC"))
					{
						
						System.out.println("I am wbc");
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][0]+=1;
						}	
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][0]+=1;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][0]+=1;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][0]+=1;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][0]+=1;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][0]+=1;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][0]+=1;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][0]+=1;
						}
						
						
					}
					else if(bloodtype.equalsIgnoreCase("RBC"))
					{
						
						System.out.println("I am RBC");
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am inside");
							inv[0][1]+=1;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][1]+=1;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][1]+=1;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][1]+=1;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][1]+=1;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][1]+=1;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][1]+=1;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][1]+=1;
						}
					}
					else if(bloodtype.equalsIgnoreCase("Platelets"))
					{
						System.out.println("I am platelets");
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][2]+=1;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][2]+=1;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][2]+=1;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][2]+=1;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][2]+=1;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][2]+=1;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][2]+=1;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][2]+=1;
						}
					}
					
					else if(bloodtype.equalsIgnoreCase("WholeBlood"))
					{
						if(bg.equalsIgnoreCase("A+"))
						{
							System.out.println("I am Inside3");
							
							inv[0][3]+=1;
						}
						else if(bg.equalsIgnoreCase("A-"))
						{
							inv[1][3]+=1;
						}
						else if(bg.equalsIgnoreCase("B+"))
						{
							inv[2][3]+=1;
						}
						else if(bg.equalsIgnoreCase("B-"))
						{
							inv[3][3]+=1;
						}
						else if(bg.equalsIgnoreCase("O+"))
						{
							inv[4][3]+=1;
						}
						else if(bg.equalsIgnoreCase("O-"))
						{
							inv[5][3]+=1;
						}
						else if(bg.equalsIgnoreCase("AB+"))
						{
							inv[6][3]+=1;
						}
						else if(bg.equalsIgnoreCase("AB-"))
						{
							inv[7][3]+=1;
						}
					}
					
					}
				}
			}
				model.put("user",user);
				model.put("inv", inv);
				 
	           return new ModelAndView("inventoryHomePage", "model", model);


}
		 else
		 {
			 return new ModelAndView("invalidLogin");
		 }

}
	 
	 
	        
	        
	public InventoryService getInventoryService() {
		return inventoryService;
	}
	public void setInventoryService(InventoryService inventoryService) {
		this.inventoryService = inventoryService;
	}
	public TestDetailsService getTestDetailsService() {
		return testDetailsService;
	}
	public void setTestDetailsService(TestDetailsService testDetailsService) {
		this.testDetailsService = testDetailsService;
	}
	
	
}

