package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.UserAccountService;

public class DonorLoginController extends SimpleFormController{

	
	UserAccountService userAccountService;
	HttpSession session;
	
	public Map referenceData(HttpServletRequest request,
            Object object, Errors errors) throws Exception {

            session = request.getSession(true);
            Map<String, Object> p = new HashMap<String, Object>();
            session.invalidate();

            return p;

   	}

	 protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response,
             Object command, BindException errors) throws Exception {
		 
		 
		 session = request.getSession(true);

		  Donor donor = (Donor)command;
		  
		  System.out.println(request.getParameter("uname"));
          Donor validateddonor=userAccountService.authenticateDonor(request.getParameter("uname"));
          System.out.println(validateddonor);
          Map<String, Object> model = new HashMap<String, Object>();
          try
          {
          if(validateddonor.getUsername() != null){
       	   System.out.println("coming");
              if(request.getParameter("pwd").equals(validateddonor.getPassword())){

                 model.put("validateddonor", validateddonor);
                 session.setAttribute("validateddonor", validateddonor);
                 System.out.println("donor authenticated");
                       
               	  
              
                     Donor don = userAccountService.getDonor(validateddonor.getDonorid());
                     
                    model.put("don", don);
                     List<Donor> donorList = userAccountService.getDonorList();
                     model.put("donorList", donorList);

                     return new ModelAndView(getSuccessView(), "model", model);
                         
	 }else
     {
   	  return new ModelAndView("unameandpwdmatch", "donor", donor);
     }
          }
          
          }
              catch(Exception e){
                  System.out.println("Enter both Username and Password");

                  model.put("useraccount", "Enter both Username and Password");
                  return new ModelAndView("unameandpwdmatch", "donor", donor);
              }

              return null;

}
	 
		public UserAccountService getUserAccountService() {
			return userAccountService;
		}

		public void setUserAccountService(UserAccountService userAccountService) {
			this.userAccountService = userAccountService;
		}
}