package com.mybank.myapp.controller;

import javax.servlet.http.HttpSession;

import java.beans.PropertyEditorSupport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;

import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.dao.DonorDAO;
import com.mybank.myapp.dao.OrganizationDAO;
import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.UserAccountService;

public class addDonorController extends SimpleFormController {

	UserAccountService userAccountService;
	OrganizationService organizationService;
	HttpSession session;

	public addDonorController() {

	}

	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		System.out.println("add donor");
		ArrayList<Organization> orglist = organizationService.getOrgList();
		System.out.print(orglist);
		model.put("orglist", orglist);
		session.setAttribute("orglist",orglist);
		return model;

	}

	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
	
		
		Donor newDonor = (Donor) command;
		Organization organ = organizationService.findOrganization(request.getParameter("organ"));
		String username = newDonor.getUsername();
		String bg=request.getParameter("bg");
		System.out.print(organ+"organ");
		newDonor.setOrganization(organ);
		newDonor.setBloodgrp(bg);
		

		boolean usernameexists = userAccountService.checkforusernameDonor(username);

		if (usernameexists == true) {
			
		    return new ModelAndView("usernameAlreadyExistsDonor");
		} else {
			userAccountService.addDonor(newDonor);
			
			return new ModelAndView(getSuccessView(), "donor", newDonor);
		}
	}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}

	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}

}
