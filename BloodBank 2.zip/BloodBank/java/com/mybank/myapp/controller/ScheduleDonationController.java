package com.mybank.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.UserAccountService;

public class ScheduleDonationController extends SimpleFormController{
	
	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	String donid;
	int id;
	
	public ScheduleDonationController()
	{
		
	}
	public Map referenceData(HttpServletRequest request,
            Object object, Errors errors) throws Exception {
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		System.out.println("add admin");
		Donor donor=(Donor)session.getAttribute("validateddonor");
		if(donor!=null)
		{
		ArrayList<Organization> orglist = organizationService.getOrgList();
		model.put("orglist", orglist);
		
		donid=request.getParameter("id");
		id=Integer.parseInt(donid);
		System.out.println(id);
		model.put("validateddonor", donor);
		session.setAttribute("model", model);
		return model;
		}
		else
		{
			return null;
		}
				
	

   	}
	
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		Donor don=(Donor)session.getAttribute("validateddonor");
		if(don!=null)
		{
		Schedule schedule = (Schedule) command;
		Organization organ = organizationService.findOrganization(request.getParameter("organ"));
		System.out.println(organ);
		schedule.setOrg(organ);
		System.out.println(request.getParameter("time"));
		String time=request.getParameter("time");
		schedule.setScheduletime(time);
		Donor donor=userAccountService.getDonor(id);
		System.out.println(donor);
		schedule.setDonor(donor);
		System.out.println(schedule.getScheduledate()+"date....");
		List<Schedule> schedulelist=scheduleService.getScheduleList();
		System.out.println(schedulelist);
		schedule.setStatus("Active");
		schedule.setAssignedstatus("Pending");
		//if(scheduleService.confirmSchedule(schedulelist,schedule)!=false)
	//	{
		scheduleService.addSchedule(schedule);		
		return new ModelAndView(getSuccessView(), "schedule", schedule);
		//}
		//else
		//{   session.setAttribute("validateddonor",don);
		//	return new ModelAndView("scheduleBooked","schedule",schedule);
	//	}
		}
		else
			return new ModelAndView("invalidLogin");
		
		
	}
	public OrganizationService getOrganizationService() {
		return organizationService;
	}
	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}
	
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	public ScheduleService getScheduleService() {
		return scheduleService;
	}
	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	
	
	
	}


