package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.UserAccountService;

public class AdminHomeController extends AbstractController {
	HttpSession session;
	UserAccountService userAccountService;
	public AdminHomeController()
	{
		
	}
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		 HttpSession session = request.getSession(true);
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 
		 if(user!=null&&  user.getRole().getRole().equals("bbadmin")&&user.getStatus().equals("Active"))
		 {
			 
			 System.out.println("hi hi hi");
			 List<User> userList = userAccountService.getUserList();
             model.put("userList", userList);
             System.out.println(userList);
				model.put("user",user);
	           return new ModelAndView("adminHomePage", "model", model);


}
		 else
		 {
			 return new ModelAndView("invalidLogin");
		 }

}
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	 
}
