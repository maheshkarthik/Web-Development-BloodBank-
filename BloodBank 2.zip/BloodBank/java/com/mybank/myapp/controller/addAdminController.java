package com.mybank.myapp.controller;

import java.awt.Window;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Role;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.RoleService;
import com.mybank.myapp.service.UserAccountService;

public class addAdminController extends SimpleFormController {
	UserAccountService userAccountService;
	OrganizationService organizationService;
	RoleService roleService;
	HttpSession session;
	String error;
	
	public addAdminController()
	{
		
	}

	
	@SuppressWarnings("unchecked")
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		 
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("superadmin"))
		 {
			 System.out.println("i am correct");
		ArrayList<Organization> orglist = organizationService.getOrgList();
		model.put("orglist", orglist);
		
		return model;
		 }
		 else
		 {
		 return null;
		 }
	    

	}
	
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
	        Map<String, Object> model = new HashMap<String, Object>();
	        User user=(User)session.getAttribute("user");
	        if(user!=null &&  user.getRole().getRole().equals("superadmin"))
			 {
				 
		User newadmin = (User) command;
		Organization organ = organizationService.findOrganization(request.getParameter("organ"));
		String username = newadmin.getUsername();
		System.out.println(organ);
		newadmin.setOrg(organ);
		newadmin.setStatus("Active");
		Role rol=roleService.findRole(request.getParameter("rol"));
		System.out.println(rol);
		newadmin.setRole(rol);
		
		

		boolean usernameexists = userAccountService.checkforusernameuser(username);

		if (usernameexists == true) {
			model.put("user", user);
		    return new ModelAndView("userNameExistsSuperAdmin","model",model);
		} else {
			userAccountService.addUser(newadmin);
			model.put("user", user);
			session.setAttribute("model",model);
			session.setAttribute("user", user);
			
			return new ModelAndView(getSuccessView(), "model", model);
		}
		
		}
	        else 
	        {
	        	JFrame frame = new JFrame("Show Message Dialog");
				JOptionPane.showMessageDialog(frame, "You are not authorized/loggedin to view this page");
	        	return new ModelAndView("home1");
	        }
	            
	}
	
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}

	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}


	public RoleService getRoleService() {
		return roleService;
	}


	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}
	
}
