package com.mybank.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.DonationDetails;
import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.TestDetails;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.DonationDetailsService;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.TestDetailsService;
import com.mybank.myapp.service.UserAccountService;

public class ProcessReqController extends SimpleFormController {
	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	DonationDetailsService donationDetailsService;
	TestDetailsService testDetailsService;
	
	
	
	public ProcessReqController()
	{
		
	}
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("nurse") &&user.getStatus().equals("Active"))
		 {      
		System.out.println("Welcom to assigning");
		List<DonationDetails> dondetlist=donationDetailsService.getDonationDetailsList();
		String donid=request.getParameter("donid");
		int donationid=Integer.parseInt(donid);
		DonationDetails donationdet=donationDetailsService.getDonationDetails(donationid);
		model.put("dondetlist", dondetlist);
		model.put("user",user);
		model.put("donationdet", donationdet);
		session.setAttribute("donationdet", donationdet);
		session.setAttribute("model", model);
		
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
		
		
		User user=(User)session.getAttribute("user");
		if(user!=null &&  user.getRole().getRole().equals("nurse")&&user.getStatus().equals("Active"))
		{
			DonationDetails dondetails=(DonationDetails)session.getAttribute("donationdet");
			System.out.println("Welcom to succesview");
			TestDetails testdet=(TestDetails) command;	
			
			dondetails.setDonationstatus("Completed");
			List<DonationDetails> dondetlist=donationDetailsService.getDonationDetailsList();
			String bt=request.getParameter("bloodtype");
			dondetails.setBarcode(request.getParameter("barcode"));
			System.out.println(dondetails+"DONATIONDETAILS");
			dondetails.setBloodproduct(bt);
			donationDetailsService.updateDonationDetails(dondetails);
			testdet.setDonationdetails(dondetails);
			testdet.setTestdate(null);
			testdet.setTestedby(null);
			testdet.setTestresult("Pending");
			testDetailsService.addTestDetails(testdet);
		
			
			
			return new ModelAndView(getSuccessView(), "user", user); 
			
		}
	return null;
		
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}
	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	public ScheduleService getScheduleService() {
		return scheduleService;
	}
	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	public DonationDetailsService getDonationDetailsService() {
		return donationDetailsService;
	}
	public void setDonationDetailsService(
			DonationDetailsService donationDetailsService) {
		this.donationDetailsService = donationDetailsService;
	}
	public TestDetailsService getTestDetailsService() {
		return testDetailsService;
	}
	public void setTestDetailsService(TestDetailsService testDetailsService) {
		this.testDetailsService = testDetailsService;
	}
	

}
