package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.DonationDetails;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.DonationDetailsService;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.UserAccountService;

public class ViewAndProcessReqController extends AbstractController{
	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	DonationDetailsService donationDetailsService;
	
	public ViewAndProcessReqController()
	{
		
	}
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		
		User user=(User)session.getAttribute("user");
		if(user!=null&&  user.getRole().getRole().equals("nurse")&&user.getStatus().equals("Active"))
		{
		
		List<DonationDetails> dondetlist=donationDetailsService.getDonationDetailsList();
		
		model.put("user",user);
		model.put("dondetlist",dondetlist);
		
		session.setAttribute("model", model);
		 return new ModelAndView("viewAndProcessReq","model",model);
		}
		else
		{
			return new ModelAndView("invalidLogin");
		}
				
	

	}
	


	public OrganizationService getOrganizationService() {
		return organizationService;
	}

	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	public ScheduleService getScheduleService() {
		return scheduleService;
	}

	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	public DonationDetailsService getDonationDetailsService() {
		return donationDetailsService;
	}
	public void setDonationDetailsService(
			DonationDetailsService donationDetailsService) {
		this.donationDetailsService = donationDetailsService;
	}
	
	

}
