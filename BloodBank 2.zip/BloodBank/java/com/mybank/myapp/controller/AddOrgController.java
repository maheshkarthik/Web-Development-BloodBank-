package com.mybank.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Role;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.RoleService;
import com.mybank.myapp.service.UserAccountService;

public class AddOrgController extends SimpleFormController {
	UserAccountService userAccountService;
	OrganizationService organizationService;
	RoleService roleService;
	HttpSession session;
	String error;
	
	public AddOrgController()
	{
		
	}

	
	@SuppressWarnings("unchecked")
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		 
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("superadmin"))
		 {
			 System.out.println("i am correct");
		ArrayList<Organization> orglist = organizationService.getOrgList();
		model.put("orglist", orglist);
		model.put("user", user);
		session.setAttribute("model", model);
		
		return model;
		 }
		 else
		 {
		 return null;
		 }
	    

	}
	
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		session = request.getSession(true);
	        Map<String, Object> model = new HashMap<String, Object>();
	        User user=(User)session.getAttribute("user");
	        if(user!=null &&  user.getRole().getRole().equals("superadmin"))
			 {
				 
		Organization org = (Organization) command;
		String orgname = org.getOrgname();
	
		
		
		

		Organization orgnameexists = organizationService.findOrganization(orgname);

		if (orgnameexists != null) {
			model.put("user", user);
			session.setAttribute("model",model);
			return new ModelAndView("orgNameExists","model",model);
		} else {
			organizationService.addOrganization(org);
			model.put("user", user);
			session.setAttribute("model",model);
			session.setAttribute("user", user);
			return new ModelAndView(getSuccessView(),"model",model);
		}
		
		}
	        else 
	        {
	        	JFrame frame = new JFrame("Show Message Dialog");
				JOptionPane.showMessageDialog(frame, "You are not authorized/loggedin to view this page");
	        	return new ModelAndView("home");
	        }
	            
	}
	
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	public OrganizationService getOrganizationService() {
		return organizationService;
	}

	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}


	public RoleService getRoleService() {
		return roleService;
	}


	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}
	
}



