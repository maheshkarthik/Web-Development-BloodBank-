package com.mybank.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.HospitalService;

public class HospitalRequestController extends SimpleFormController{
	
	
	HttpSession session;
	HospitalService hospitalService;
	 ArrayList<HosRequest> reqarray= new ArrayList<HosRequest>();
	public HospitalRequestController() {
		// TODO Auto-generated constructor stub
	}
	public Map referenceData(HttpServletRequest request, Object object,
			Errors errors) throws Exception {
		 session = request.getSession(true);
		
		 Map<String, Object> model = new HashMap<String, Object>();
		 User user=(User)session.getAttribute("user");
		 System.out.println(user);
		 if(user!=null &&  user.getRole().getRole().equals("hadmin") &&user.getStatus().equals("Active"))
		 {      
		System.out.println("Welcom to assigning");
		
		model.put("user",user);
		
		
		session.setAttribute("model", model);
		
		return model;
		 }
		 else
		 {
			 return null;
		 }
	     		
}
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
session = request.getSession(true);
Map<String, Object> model = new HashMap<String, Object>();

		User user=(User)session.getAttribute("user");
		if(user!=null &&  user.getRole().getRole().equals("hadmin")&&user.getStatus().equals("Active"))
		{
			
			mahesh:
				{
			for(int i=0;i<reqarray.size();i++)
				{
				if(reqarray.get(i).getBloodgroup().equals(request.getParameter("bloodgroup"))&& reqarray.get(i).getProducttype().equals(request.getParameter("bloodtype")))
				{
				reqarray.get(i).setQuantity(reqarray.get(i).getQuantity()+Integer.parseInt(request.getParameter("quantity")));
				break mahesh;
				}
			
			}
			
			HosRequest hosreq=(HosRequest)command;
			hosreq.setBloodgroup(request.getParameter("bloodgroup"));
			hosreq.setProducttype(request.getParameter("bloodtype"));
			hosreq.setQuantity(Integer.parseInt(request.getParameter("quantity")));
			
			hospitalService.addHosRequest(hosreq);
			
			
			reqarray.add(hosreq);
			
		}	
			
			model.put("reqarray",reqarray);
			session.setAttribute("reqarray",reqarray);
			session.setAttribute("model", model);
			for(int i=0;i<reqarray.size();i++)
			System.out.println(reqarray.get(i));
			
			return new ModelAndView(getSuccessView()); 
			
		}
		return null;
	}
	public HospitalService getHospitalService() {
		return hospitalService;
	}
	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}
	public ArrayList<HosRequest> getReqarray() {
		return reqarray;
	}
	public void setReqarray(ArrayList<HosRequest> reqarray) {
		this.reqarray = reqarray;
	}
	
	

}
