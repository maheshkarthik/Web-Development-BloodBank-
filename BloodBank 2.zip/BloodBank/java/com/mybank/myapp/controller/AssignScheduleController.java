package com.mybank.myapp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.Schedule;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.OrganizationService;
import com.mybank.myapp.service.ScheduleService;
import com.mybank.myapp.service.UserAccountService;

public class AssignScheduleController extends AbstractController {
	
	HttpSession session;
	OrganizationService organizationService;
	UserAccountService userAccountService;
	ScheduleService scheduleService;
	
	
	public AssignScheduleController()
	{
		
	}
	
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		
		User user=(User)session.getAttribute("user");
		if(user!=null&&  user.getRole().getRole().equals("receptionist")&&user.getStatus().equals("Active"))
		{
		Organization organ=organizationService.findOrganization(user.getOrg().getOrgname());
		List<Schedule> schedulelist=scheduleService.getScheduleList();
		
		List<User> nurselist= userAccountService.getNurseList(user.getOrg().getOrgname());
        model.put("nurselist", nurselist);
        session.setAttribute("nurselist", nurselist);
		model.put("user",user);
		model.put("schedulelist", schedulelist);
		System.out.println(nurselist);
		session.setAttribute("model", model);
		 return new ModelAndView("assignSchedules","model",model);
		}
		else
		{
			return new ModelAndView("invalidLogin");
		}
				
	

   	}
	


	public OrganizationService getOrganizationService() {
		return organizationService;
	}

	public void setOrganizationService(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}

	public ScheduleService getScheduleService() {
		return scheduleService;
	}

	public void setScheduleService(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	
	

}
