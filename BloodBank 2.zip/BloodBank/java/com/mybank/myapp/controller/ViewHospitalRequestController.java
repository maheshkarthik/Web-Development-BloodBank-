package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.HosOrder;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.HospitalService;

public class ViewHospitalRequestController  extends AbstractController{
	
	
	HttpSession session;
	HospitalService hospitalService;
	
	public ViewHospitalRequestController()
	{
		
	}

	 protected ModelAndView handleRequestInternal( 
			 HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		
		 User user=(User)session.getAttribute("user");
		 System.out.println("outside");
		 
		 if(user!=null&&  user.getRole().getRole().equalsIgnoreCase("inventorymanager")&&user.getStatus().equals("Active"))
		 {
			 List<HosOrder> hsordlist=hospitalService.getHosOrderList();
			 model.put("hsordlist", hsordlist);
			 model.put("user",user);
			 session.setAttribute("model", model);
			 return new ModelAndView("viewHospitalOrder","model",model);
		 }
		return null;
	 }

	public HospitalService getHospitalService() {
		return hospitalService;
	}

	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}
	 
	 
}
