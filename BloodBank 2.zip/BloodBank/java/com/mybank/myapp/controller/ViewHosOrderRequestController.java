package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.HosOrder;
import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.HospitalService;

public class ViewHosOrderRequestController extends AbstractController {
	HttpSession session;
	HospitalService hospitalService;
	
	public ViewHosOrderRequestController()
	{
		
	}


	 protected ModelAndView handleRequestInternal( 
			 HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		session = request.getSession(true);
		Map<String, Object> model = new HashMap<String, Object>();
		
		 User user=(User)session.getAttribute("user");
		 System.out.println("outside");
		 
		
			 List<HosRequest> hsreqlist=hospitalService.getHosRequestList();
			 String ordid=request.getParameter("id");
			 System.out.println(ordid+"order number");
			 int orderid=Integer.parseInt(ordid);
			 model.put("hsreqlist", hsreqlist);
			 model.put("user",user);
			 model.put("orderid", orderid);
			 session.setAttribute("model", model);
			 return new ModelAndView("viewHospitalOrderRequests","model",model);
		 
	 }

	public HospitalService getHospitalService() {
		return hospitalService;
	}

	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}
	 
	 
}

