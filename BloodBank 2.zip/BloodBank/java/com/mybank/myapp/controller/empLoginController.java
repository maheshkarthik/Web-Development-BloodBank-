package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.UserAccountService;

public class empLoginController extends SimpleFormController {
	
	UserAccountService userAccountService;
	HttpSession session;
	
	public empLoginController()
	{
		
	}

	 public Map referenceData(HttpServletRequest request,
	            Object object, Errors errors) throws Exception {

	            session = request.getSession(true);
	            Map<String, Object> p = new HashMap<String, Object>();
	            session.invalidate();

	            return p;

	   	}
	 
	 protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response,
             Object command, BindException errors) throws Exception {

          User user = (User)command;
          System.out.println(request.getParameter("uname"));
               User validateduser=userAccountService.authenticateUser(request.getParameter("uname"));
              
               System.out.println(validateduser);
               Map<String, Object> model = new HashMap<String, Object>();
               session = request.getSession(true);
              
               try
               {
               if(validateduser.getUsername() != null){
            	   System.out.println("coming");
                   if(request.getParameter("passwd").equals(validateduser.getPassword())){

                      model.put("user", validateduser);
                      System.out.println("user authenticated");
                      
                      if(validateduser.getRole().getRole().equals("superadmin")){
                    	  
                    	 
                    	  
                    	  System.out.println("Super Admin authenitcated");
                          User emp = userAccountService.getUser(validateduser.getEmpid());
                         
                          
                         model.put("emp", emp);
                         session.setAttribute("user", validateduser);
                          List<User> userList = userAccountService.getUserList();
                          model.put("userList", userList);
                        
                          session.setAttribute("model", model);
                          

                          return new ModelAndView(getSuccessView(), "model", model);
                    }
                      else if(validateduser.getRole().getRole().equals("bbadmin") && validateduser.getStatus().equals("Active"))
                      {
                    	  System.out.println("Admin authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                           List<User> userList = userAccountService.getUserList();
                           model.put("userList", userList);
                           return new ModelAndView("adminHomePage", "model", model);
                   	   
                      }
                      else if(validateduser.getRole().getRole().equals("receptionist"))
                      {
                    	  System.out.println("receptionist authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                            return new ModelAndView("recepHomePage", "model", model);
                   	   
                      }
                      else if(validateduser.getRole().getRole().equals("nurse"))
                      {
                    	  System.out.println("nurse authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                            return new ModelAndView("nurseHomePage", "model", model);
                   	   
                      }
                      else if(validateduser.getRole().getRole().equals("labtechnician"))
                      {
                    	  System.out.println("labtechnician authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                            return new ModelAndView("labHomePage", "model", model);
                   	   
                      }
                      else if(validateduser.getRole().getRole().equals("inventorymanager"))
                      {
                    	  System.out.println("inventorymanager authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                            return new ModelAndView("redirect:inventoryhome.htm", "model", model);
                   	   
                      }
                      
                      else if(validateduser.getRole().getRole().equals("hadmin"))
                      {
                    	  System.out.println("hospital authenitcated");
                    	  User emp = userAccountService.getUser(validateduser.getEmpid());
                    	  model.put("user", validateduser);
                          model.put("emp", emp);
                          session.setAttribute("user", validateduser);
                            return new ModelAndView("redirect:hospitalhome.htm", "model", model);
                   	   
                      }
                      
                      }
                   else
                   {
                	   return new ModelAndView("unameandpwdmatch", "model", model);
                   }
                      
               }
               
               }
               catch(Exception e){
                   System.out.println("Enter both Username and Password");
                 
                   return new ModelAndView("unameandpwdmatch", "model", model);
               }

               return null;
	 }

	public UserAccountService getUserAccountService() {
		return userAccountService;
	}

	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
               
               
        
               
	 }

