package com.mybank.myapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mybank.myapp.pojo.User;
import com.mybank.myapp.service.UserAccountService;

public class SuperAdminHomeController extends AbstractController {
	HttpSession session;
	UserAccountService userAccountService;
	
	public SuperAdminHomeController()
	{
		
	}
	 protected ModelAndView handleRequestInternal(
	            HttpServletRequest request, 
	            HttpServletResponse response) throws Exception {
		 session = request.getSession(true);
	        Map<String, Object> model = new HashMap<String, Object>();
	       
	             
	             
	           
	             User user=(User)session.getAttribute("user");
	             System.out.println("KAKA"+user);
	            if (user!= null && user.getRole().getRole().equals("superadmin")) 
	            {
	            	List<User> userList = userAccountService.getUserList();
                    model.put("userList", userList);
	            	model.put("user", user);
	           return new ModelAndView("superAdminHomePage", "model", model);
	            }
				return null;
				

}
	public UserAccountService getUserAccountService() {
		return userAccountService;
	}
	public void setUserAccountService(UserAccountService userAccountService) {
		this.userAccountService = userAccountService;
	}
	        
}
