package com.mybank.myapp.pojo;

import java.util.Date;


public class HosOrder {
	
	public int orderid;
	private String orderdate;
    private String orderstatus;
    private String Hospitalname;
    private String bloodbankname;
    private int amount;
   
    
    HosOrder()
    {
    	
    }


	public int getOrderid() {
		return orderid;
	}


	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}



	public String getOrderdate() {
		return orderdate;
	}


	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}


	public String getOrderstatus() {
		return orderstatus;
	}


	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}


	public String getHospitalname() {
		return Hospitalname;
	}


	public void setHospitalname(String hospitalname) {
		Hospitalname = hospitalname;
	}


	public String getBloodbankname() {
		return bloodbankname;
	}


	public void setBloodbankname(String bloodbankname) {
		this.bloodbankname = bloodbankname;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}

}