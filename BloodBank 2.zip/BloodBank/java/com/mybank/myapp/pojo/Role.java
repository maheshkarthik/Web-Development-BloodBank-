package com.mybank.myapp.pojo;

public class Role {
	private long roleid;
	private String role;
	
	Role()
	{
		
	}

	public long getRoleid() {
		return roleid;
	}

	public void setRoleid(long roleid) {
		this.roleid = roleid;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	

}
