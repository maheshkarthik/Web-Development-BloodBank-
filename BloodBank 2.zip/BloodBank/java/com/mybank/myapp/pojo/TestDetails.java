package com.mybank.myapp.pojo;

import java.util.Date;

public class TestDetails {
	private long testid;
	private String testedby;
	private String testdate;
	private String testresult;
	private DonationDetails donationdetails;
	private String addedtoinventory;
	
	public TestDetails()
	{
		
	}

	public long getTestid() {
		return testid;
	}

	public void setTestid(long testid) {
		this.testid = testid;
	}

	public String getTestedby() {
		return testedby;
	}

	public void setTestedby(String testedby) {
		this.testedby = testedby;
	}

	



	public String getTestdate() {
		return testdate;
	}

	public void setTestdate(String testdate) {
		this.testdate = testdate;
	}

	public String getTestresult() {
		return testresult;
	}

	public void setTestresult(String testresult) {
		this.testresult = testresult;
	}

	public DonationDetails getDonationdetails() {
		return donationdetails;
	}

	public void setDonationdetails(DonationDetails donationdetails) {
		this.donationdetails = donationdetails;
	}

	public String getAddedtoinventory() {
		return addedtoinventory;
	}

	public void setAddedtoinventory(String addedtoinventory) {
		this.addedtoinventory = addedtoinventory;
	}

	
	
	

}
