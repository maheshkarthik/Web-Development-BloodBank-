package com.mybank.myapp.pojo;

public class Inventory {
	private long inventoryid;
	private String bloodgrp;
	private int wbcquantity;
	private int rbcquantity;
	private int plateletsquantity;
	private int wholebloodquantity;
	
	public Inventory()
	{
	
	}

	public long getInventoryid() {
		return inventoryid;
	}

	public void setInventoryid(long inventoryid) {
		this.inventoryid = inventoryid;
	}

	public String getBloodgrp() {
		return bloodgrp;
	}

	public void setBloodgrp(String bloodgrp) {
		this.bloodgrp = bloodgrp;
	}

	public int getWbcquantity() {
		return wbcquantity;
	}

	public void setWbcquantity(int wbcquantity) {
		this.wbcquantity = wbcquantity;
	}

	public int getRbcquantity() {
		return rbcquantity;
	}

	public void setRbcquantity(int rbcquantity) {
		this.rbcquantity = rbcquantity;
	}

	public int getPlateletsquantity() {
		return plateletsquantity;
	}

	public void setPlateletsquantity(int plateletsquantity) {
		this.plateletsquantity = plateletsquantity;
	}

	public int getWholebloodquantity() {
		return wholebloodquantity;
	}

	public void setWholebloodquantity(int wholebloodquantity) {
		this.wholebloodquantity = wholebloodquantity;
	}

	
}
