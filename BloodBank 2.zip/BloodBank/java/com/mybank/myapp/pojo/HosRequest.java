package com.mybank.myapp.pojo;

public class HosRequest {
	private int reqid;
	private String bloodgroup;
    private String producttype;
    private int quantity;
    private int hosorder;
    HosRequest()
    {
    	
    }

	public int getReqid() {
		return reqid;
	}

	public void setReqid(int reqid) {
		this.reqid = reqid;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getHosorder() {
		return hosorder;
	}

	public void setHosorder(int hosorder) {
		this.hosorder = hosorder;
	}


	

	
    

}
