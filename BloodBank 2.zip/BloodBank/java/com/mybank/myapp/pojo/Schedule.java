package com.mybank.myapp.pojo;
import java.util.Date;

public class Schedule {
	private long scheduleid;
	private Date scheduledate;
	private String scheduletime;
	private Donor donor;
	private Organization org;
	private String status;
	private String assignedstatus;
	
	Schedule()
	{
		
	}

	public long getScheduleid() {
		return scheduleid;
	}

	public void setScheduleid(long scheduleid) {
		this.scheduleid = scheduleid;
	}

	public Date getScheduledate() {
		return scheduledate;
	}

	public void setScheduledate(Date scheduledate) {
		this.scheduledate = scheduledate;
	}

	
	

	public String getScheduletime() {
		return scheduletime;
	}

	public void setScheduletime(String scheduletime) {
		this.scheduletime = scheduletime;
	}

	public Donor getDonor() {
		return donor;
	}

	public void setDonor(Donor donor) {
		this.donor = donor;
	}

	public Organization getOrg() {
		return org;
	}

	public void setOrg(Organization org) {
		this.org = org;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignedstatus() {
		return assignedstatus;
	}

	public void setAssignedstatus(String assignedstatus) {
		this.assignedstatus = assignedstatus;
	}
	

}
