package com.mybank.myapp.pojo;

import java.util.Date;

public class DonationDetails {
private long donationid;
private String extractedby;
private Date donationdate;
private String bloodproduct;
private String donationstatus;
private String barcode;
private Schedule schedule;

DonationDetails()
{
	
}

public long getDonationid() {
	return donationid;
}

public void setDonationid(long donationid) {
	this.donationid = donationid;
}

public String getExtractedby() {
	return extractedby;
}

public void setExtractedby(String extractedby) {
	this.extractedby = extractedby;
}

public Date getDonationdate() {
	return donationdate;
}

public void setDonationdate(Date donationdate) {
	this.donationdate = donationdate;
}

public String getBloodproduct() {
	return bloodproduct;
}

public void setBloodproduct(String bloodproduct) {
	this.bloodproduct = bloodproduct;
}

public String getDonationstatus() {
	return donationstatus;
}

public void setDonationstatus(String donationstatus) {
	this.donationstatus = donationstatus;
}

public String getBarcode() {
	return barcode;
}

public void setBarcode(String barcode) {
	this.barcode = barcode;
}


public Schedule getSchedule() {
	return schedule;
}

public void setSchedule(Schedule schedule) {
	this.schedule = schedule;
}


}