package com.mybank.myapp.pojo;

public class User {
	    private long empid;
	    private String firstname;
	    private String lastname;
	    private int ssn;
	    private String addressline1;
	    private String addressline2;
	    private String city;
	    private String state;
	    private int zipcode;
	    private String username;
	    private String password;
	    private Role role;
	    private int phno;
	    private Organization org;
	    private String status;
	    
	    User() {
	    }

		public long getEmpid() {
			return empid;
		}

		public void setEmpid(long empid) {
			this.empid = empid;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public int getSsn() {
			return ssn;
		}

		public void setSsn(int ssn) {
			this.ssn = ssn;
		}

		public String getAddressline1() {
			return addressline1;
		}

		public void setAddressline1(String addressline1) {
			this.addressline1 = addressline1;
		}

		public String getAddressline2() {
			return addressline2;
		}

		public void setAddressline2(String addressline2) {
			this.addressline2 = addressline2;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		

		public int getZipcode() {
			return zipcode;
		}

		public void setZipcode(int zipcode) {
			this.zipcode = zipcode;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public Role getRole() {
			return role;
		}

		public void setRole(Role role) {
			this.role = role;
		}

		public int getPhno() {
			return phno;
		}

		public void setPhno(int phno) {
			this.phno = phno;
		}

		public Organization getOrg() {
			return org;
		}

		public void setOrg(Organization org) {
			this.org = org;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		
		

		

}
