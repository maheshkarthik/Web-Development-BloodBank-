package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.OrganizationDAO;
import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Organization;

public class OrganizationService {
	OrganizationDAO organizationDAO;

	public OrganizationService() {

	}
	 public void addOrganization(Organization d){
		 organizationDAO.addOrganization(d);
	    }

	// organization services
	public ArrayList<Organization> getOrgList() {
		ArrayList<Organization> orgs = (ArrayList<Organization>) organizationDAO.getOrganizationList();
		return orgs;
	}
public Organization findOrganization(String orgname)
{
	List<Organization> orglist=organizationDAO.getOrganizationList();
	for(Organization org:orglist)
	{
		if(org.getOrgname().equalsIgnoreCase(orgname))
		{
			return org;
		}
	
	}
	return null;
}
	public OrganizationDAO getOrganizationDAO() {
		return organizationDAO;
	}

	public void setOrganizationDAO(OrganizationDAO organizationDAO) {
		this.organizationDAO = organizationDAO;
	}
}
