package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.RoleDAO;
import com.mybank.myapp.pojo.Role;

public class RoleService {
	
	RoleDAO roleDAO;

	public RoleService() {
		
	}
	
	public ArrayList<Role> getRoleList() {
		ArrayList<Role> roles = (ArrayList<Role>) roleDAO.getRoleList();
		return roles;
	}
public Role findRole(String rolename)
{
	List<Role> rolelist=roleDAO.getRoleList();
	for(Role role:rolelist)
	{
		if(role.getRole().equalsIgnoreCase(rolename))
		{
			return role;
		}
	
	}
	return null;

}

public RoleDAO getRoleDAO() {
	return roleDAO;
}

public void setRoleDAO(RoleDAO roleDAO) {
	this.roleDAO = roleDAO;
}


}
