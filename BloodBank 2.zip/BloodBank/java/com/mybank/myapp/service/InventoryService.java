package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;


import com.mybank.myapp.dao.InventoryDAO;
import com.mybank.myapp.pojo.Inventory;

public class InventoryService {
	InventoryDAO inventoryDAO;
	private static final String SMTP_HOST_NAME = "smtp.gmail.com";
	private static final String SMTP_PORT = "465";
	private static final String emailMsgTxt = "Test Message Contents";
	private static final String emailSubjectTxt = "A test from gmail";
	private static final String emailFromAddress = "mahesh.karthikd@gmail.com";
	private static final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
	private static final String[] sendTo = {"mahesh_matitude@yahoo.com"};
	
	public InventoryService()
	{
		
	}
	
			
	
	 public void addInventory(Inventory d){
		 inventoryDAO.addInventory(d);
	    }
	    public void updateInventory(Inventory d){
	    	inventoryDAO.updateInventory(d);
	    }
	    public Inventory getInventory(long id){
	    	Inventory d = inventoryDAO.getInventory(id);
	        return d;
	    }
	    public List<Inventory> getInventoryList(){
	        List<Inventory> Inventorylist = inventoryDAO.getInventoryList();
	        List<Inventory> activenventorylist = new ArrayList<Inventory>();
	        for(Inventory u: Inventorylist){
	            
	        	activenventorylist.add(u);
	            
	        }
	        return activenventorylist;
	    }

		public InventoryDAO getInventoryDAO() {
			return inventoryDAO;
		}

		public void setInventoryDAO(InventoryDAO inventoryDAO) {
			this.inventoryDAO = inventoryDAO;
		}

		
}
