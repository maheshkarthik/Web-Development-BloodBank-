package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.DonorDAO;
import com.mybank.myapp.dao.UserDAO;
import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.User;

public class UserAccountService {
	
	DonorDAO donorDAO;
	UserDAO userDAO;
	
	public UserAccountService()
	{
		
	}
	
	//Donor services
	
	 public void addDonor(Donor d){
		 donorDAO.addDonor(d);
	    }
	    public void updateDonor(Donor d){
	        donorDAO.updateDonor(d);
	    }
	    public Donor getDonor(long id){
	        Donor d = donorDAO.getDonor(id);
	        return d;
	    }
	    
	    
	    public Donor authenticateDonor(String un){

	        List<Donor> donors = donorDAO.getDonorList();
	        for(Donor u: donors){
	            if(u.getUsername().equals(un)){
	                return u;
	            }
	        }
	        return null;
	    }
	    
	    public Donor getDonor(String un){

	        List<Donor> donors = donorDAO.getDonorList();
	        for(Donor u: donors){
	            if(u.getUsername().equals(un)){
	                return u;
	            }
	        }
	        return null;
	    }
	    
	    public boolean checkforusernameDonor(String un){

	        List<Donor> donors = donorDAO.getDonorList();
	        for(Donor u: donors){
	            if(u.getUsername().equals(un)){
	                return true;
	            }
	        }
	        return false;
	    }
	    public List<Donor> getDonorList(){
	        List<Donor> donors = donorDAO.getDonorList();
	        List<Donor> activedonors = new ArrayList<Donor>();
	        for(Donor u: donors){
	            
	                activedonors.add(u);
	            
	        }
	        return activedonors;
	    }
	    public List<Donor> getDonorHistory(int id){
	        Donor ua = donorDAO.getDonor(id);
	        List<Donor> donors = donorDAO.getDonorList();
	        List<Donor> donorhis = new ArrayList<Donor>();
	        for(Donor u: donors){
	            if(u.getUsername().equals(ua.getUsername())){
	                donorhis.add(u);
	            }
	        }
	        return donorhis;
	    }
	    public void revertDonor(int id){
	        Donor ur = getDonor(id);
	        Donor ua = authenticateDonor(ur.getUsername());
	     //   ur.setStatus(1);
	        updateDonor(ur);
	      //  ua.setStatus(0);
	        updateDonor(ua);
	    }

	    public void disableDonor(int id){
	        Donor u = donorDAO.getDonor(id);
	      //  u.setStatus(0);
	        donorDAO.updateDonor(u);
	    }

	    public List<Donor> getDisabledDonors(){

	        List<Donor> donors = donorDAO.getDonorList();
	        List<Donor> disableddonors = new ArrayList<Donor>();
	        for(Donor u: donors){
	         //   if(u.getStatus()==0){
	                disableddonors.add(u);
	         //   }
	        }
	        return disableddonors;
	    }

	    public void activateDonor(int id){
	        Donor u = donorDAO.getDonor(id);
	      //  u.setStatus(1);
	        donorDAO.updateDonor(u);
	    }

	    public void deleteDonor(int id){
	        Donor u = donorDAO.getDonor(id);
	        donorDAO.deleteDonor(u);
	    }

		public DonorDAO getDonorDAO() {
			return donorDAO;
		}

		public void setDonorDAO(DonorDAO donorDAO) {
			this.donorDAO = donorDAO;
		}

		public UserDAO getUserDAO() {
			return userDAO;
		}

		public void setUserDAO(UserDAO userDAO) {
			this.userDAO = userDAO;
		}
		
		
		//User Sevice
		
		public void addUser(User d){
			 userDAO.addUser(d);
		    }
		    public void updateUser(User d){
		        userDAO.updateUser(d);
		    }
		    public User getUser(long l){
		    	User d = userDAO.getUser(l);
		        return d;
		    }
		    public User authenticateUser(String un){

		        List<User> users = userDAO.getUserList();
		        for(User u: users){
		            if(u.getUsername().equals(un)){
		                return u;
		            }
		        }
		        return null;
		    }
		    
		    public boolean checkforusernameuser(String un){

		        List<User> users = userDAO.getUserList();
		        for(User u: users){
		            if(u.getUsername().equals(un)){
		                return true;
		            }
		        }
		        return false;
		    }
		    
		    public boolean existinguser(String un,String pd){

		        List<User> users = userDAO.getUserList();
		        for(User u: users){
		            if(u.getUsername().equals(un)&& u.getPassword().equals(pd)){
		                return true;
		            }
		        }
		        return false;
		    }
		    
		    public List<User> getUserList(){
		        List<User> users = userDAO.getUserList();
		        List<User> activeusers = new ArrayList<User>();
		        for(User u: users){
		            
		                activeusers.add(u);
		            
		        }
		        return activeusers;
		    }
		
		  

		    public void disableUser(int id){
		    	User u = userDAO.getUser(id);
		      u.setStatus("InActive");
		        userDAO.updateUser(u);
		    }
		    
		    public void enableUser(int id){
		    	User u = userDAO.getUser(id);
		      u.setStatus("Active");
		        userDAO.updateUser(u);
		    }

		    public List<User> getDisabledUsers(){

		        List<User> users = userDAO.getUserList();
		        List<User> disabledusers = new ArrayList<User>();
		        for(User u: users){
		            if(u.getStatus().equals("InActive")){
		                disabledusers.add(u);
		            }
		        }
		        return disabledusers;
		    }

		    public void activateUser(int id){
		        User u = userDAO.getUser(id);
		      //  u.setStatus(1);
		        userDAO.updateUser(u);
		    }

		    public void deleteUser(int id){
		    	User u = userDAO.getUser(id);
		        userDAO.deleteUser(u);
		    }

		    public List<User> getNurseList(String org){
		        
		    	 List<User> users = userDAO.getUserList();
		        List<User> nurselist = new ArrayList<User>();
		        for(User u: users){
		            if(u.getOrg().getOrgname().equals(org) && u.getRole().getRole().equals("nurse"))
		            {
		                System.out.println("inside nurselist");
		            	nurselist.add(u);
		            }
		            	
		           		        }
		        return nurselist;
		    }



}
