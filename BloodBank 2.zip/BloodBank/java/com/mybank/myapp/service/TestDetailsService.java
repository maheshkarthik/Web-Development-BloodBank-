package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.TestDetailsDAO;
import com.mybank.myapp.pojo.TestDetails;

public class TestDetailsService  {
	TestDetailsDAO testdetailsDAO;
	
	public TestDetailsService()
	{
		
	}
	
	 public void addTestDetails(TestDetails d){
		 testdetailsDAO.addTestDetails(d);
	    }
	 public void delTestDetails(TestDetails d){
		 testdetailsDAO.deleteTestDetails(d);
	    }
	    public void updatetestDetails(TestDetails d){
	    	testdetailsDAO.updateTestDetails(d);
	    }
	    public TestDetails getTestDetails(long id){
	    	TestDetails d = testdetailsDAO.getTestDetails(id);
	        return d;
	    }
	    public List<TestDetails> getTestDetailsList(){
	        List<TestDetails> testdetlist = testdetailsDAO.getTestDetailsList();
	       
	        return testdetlist;
	    }

		public TestDetailsDAO getTestdetailsDAO() {
			return testdetailsDAO;
		}

		public void setTestdetailsDAO(TestDetailsDAO testdetailsDAO) {
			this.testdetailsDAO = testdetailsDAO;
		}
	    

}
