package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.DonationDetailsDAO;
import com.mybank.myapp.pojo.DonationDetails;
import com.mybank.myapp.pojo.Schedule;

public class DonationDetailsService {
   DonationDetailsDAO donationdetailsDAO;
   
   public DonationDetailsService()
   {
	   
   }

	 public void addDonationDetails(DonationDetails d){
		 donationdetailsDAO.addDonationDetails(d);
	    }
	    public void updateDonationDetails(DonationDetails d){
	    	donationdetailsDAO.updateDonationDetails(d);
	    }
	    public DonationDetails getDonationDetails(long id){
	    	DonationDetails d = donationdetailsDAO.getDonationDetails(id);
	        return d;
	    }
	    public List<DonationDetails> getDonationDetailsList(){
	        List<DonationDetails> dondetlist = donationdetailsDAO.getDonationDetailsList();
	        List<DonationDetails> activedonationdet = new ArrayList<DonationDetails>();
	        for(DonationDetails u: dondetlist){
	            
	        	activedonationdet.add(u);
	            
	        }
	        return activedonationdet;
	    }
	    
	    public boolean confirmappointment(List<DonationDetails> dondetlist,DonationDetails dondet)
	    {
	    	for(DonationDetails d:dondetlist)
	    	{
	    		System.out.println("one");
	    		if(dondet.getSchedule().getScheduledate().equals(d.getSchedule().getScheduledate())&& dondet.getSchedule().getScheduletime().equals(d.getSchedule().getScheduletime())&& dondet.getExtractedby().equals(d.getExtractedby()))
	    		{
	    			System.out.println("two");
	    			return false;
	    		}
	    	}
	    	return true;
	    }

		public DonationDetailsDAO getDonationdetailsDAO() {
			return donationdetailsDAO;
		}

		public void setDonationdetailsDAO(DonationDetailsDAO donationdetailsDAO) {
			this.donationdetailsDAO = donationdetailsDAO;
		}
	    
			    
	   
	    }
