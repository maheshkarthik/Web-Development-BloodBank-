package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.mybank.myapp.dao.HosOrderDAO;
import com.mybank.myapp.dao.HosRequestDAO;
import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.HosOrder;
import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.Organization;
import com.mybank.myapp.pojo.TestDetails;

public class HospitalService {
	
	HosRequestDAO hosrequestDAO;
	HosOrderDAO hosorderDAO;
	OrganizationService organizationService;
	TestDetailsService  testDetailsService;
	
	public HospitalService() {
		// TODO Auto-generated constructor stub
	}
	 public void addHosRequest(HosRequest d){
		 hosrequestDAO.addHosRequest(d);
	    }
	    public void updateHosRequest(HosRequest d){
	    	hosrequestDAO.updateHosRequest(d);
	    }
	    public HosRequest getHosRequest(long id){
	    	HosRequest d = hosrequestDAO.getHosRequest(id);
	        return d;
	    }
	    public void deleteHosRequest(HosRequest d){
	    	hosrequestDAO.deleteHosRequest(d);
	    }
	    public List<HosRequest> getHosRequestList(){
	        List<HosRequest> HosRequestdetlist = hosrequestDAO.getHosRequestList();
	       
	        return HosRequestdetlist;
	    }
	    
	    
	    public Organization getnearestorg(int zipcode,ArrayList<HosRequest> reqarray)
	    {
	          List<Organization> orglist= organizationService.getOrgList();
	         
	          for(Organization org:orglist)
	      {
	              
	         
	        	  for(int i=0;i<1000;i++)
	              {
	        		 if((org.getZipcode()== zipcode && compareInventory(reqarray,org)) || (org.getZipcode()==(zipcode+i)&&compareInventory(reqarray,org))||(org.getZipcode()==(zipcode-i)&&compareInventory(reqarray,org)))
	        		 {
	        			
	        				 return org;
	        			
	        		 }
	          }
	      }
	          return null;
	    }
	      //code for finding the nearest organisation
	public Boolean compareInventory(ArrayList<HosRequest> reqarray, Organization org){
	    Boolean flag = false;
	    
	    for(int i=0;i<reqarray.size();i++){
	    	
	        int TotalQuantity=0;
	        String bg=reqarray.get(i).getBloodgroup();
	        System.out.println(bg);
	        String bt=reqarray.get(i).getProducttype();
	        System.out.println(bt);
	        int q=(reqarray.get(i).getQuantity());
	        System.out.println(q+"Q");
	        
	    	List<TestDetails> tdlist=testDetailsService.getTestDetailsList();
	    	for(TestDetails td:tdlist)
	    	{
	    		System.out.println("firststep");
	    		if(td.getTestresult().equalsIgnoreCase("Usable"))
			{
	    			System.out.println("secondstep");
	    			
	    			Donor donor=td.getDonationdetails().getSchedule().getDonor();
	    		if(td.getDonationdetails().getSchedule().getOrg().getOrgname().equalsIgnoreCase(org.getOrgname()) && td.getDonationdetails().getBloodproduct().equals(bt)&& donor.getBloodgrp().equals(bg))
	    		{
	    			System.out.println("superman");
	    			TotalQuantity+=1;
	    		}
			}
	    	}
	    	if(q<=TotalQuantity){
                flag= true;
            }
         else
            {
                return false;
              }
			    }
	    
	  
	    if(flag==true)
	     {
	    
	    	for(int i=0;i<reqarray.size();i++){
		    	
		        int TotalQuantity=0;
		        String bg=reqarray.get(i).getBloodgroup();
		        System.out.println(bg);
		        String bt=reqarray.get(i).getProducttype();
		        System.out.println(bt);
		        int q=(reqarray.get(i).getQuantity());
		        System.out.println(q+"Q");
		        List<TestDetails> tdlist=testDetailsService.getTestDetailsList();
		        Collection c=tdlist;
		        Iterator compare=c.iterator();
		        mahesh:{
		        while(compare.hasNext())
		           {
		        	TestDetails td=(TestDetails)compare.next();
		    		System.out.println("BONJOVI111111");
		    		if(td.getTestresult().equalsIgnoreCase("Usable"))
				{
		    			System.out.println("BONJOVI2222222");
		    			
		    			Donor donor=td.getDonationdetails().getSchedule().getDonor();
		    		if(td.getDonationdetails().getSchedule().getOrg().getOrgname().equalsIgnoreCase(org.getOrgname()) && td.getDonationdetails().getBloodproduct().equals(bt)&& donor.getBloodgrp().equals(bg))
		    		{
		    			System.out.println("BONJOVI3333333");
		    			TotalQuantity+=1;
		    			//testDetailsService.delTestDetails(td);
		    		}
				}
		    		 if(q<=TotalQuantity){
		    			 testDetailsService.delTestDetails(td);
                         break mahesh;
		    	}
		           }
	    	}

	   	    }
	     }
	    return flag;
	    }
	          
	public void addHosOrder(HosOrder d){
		 hosorderDAO.addHosOrder(d);
	    }
	    public void updateHosOrder(HosOrder d){
	    	hosorderDAO.updateHosOrder(d);
	    }
	    
	    public void deleteHosOrder(HosOrder d){
	    	hosorderDAO.deleteHosOrder(d);
	    }
	    public HosOrder getHosOrder(int id){
	    	HosOrder d = hosorderDAO.getHosOrder(id);
	        return d;
	    }
	    public List<HosOrder> getHosOrderList(){
	        List<HosOrder> HosOrderdetlist = hosorderDAO.getHosOrderList();
	       
	        return HosOrderdetlist;
	    }
	
		public HosRequestDAO getHosrequestDAO() {
			return hosrequestDAO;
		}
		public void setHosrequestDAO(HosRequestDAO hosrequestDAO) {
			this.hosrequestDAO = hosrequestDAO;
		}
		
		public OrganizationService getOrganizationService() {
			return organizationService;
		}
		public void setOrganizationService(OrganizationService organizationService) {
			this.organizationService = organizationService;
		}
		public TestDetailsService getTestDetailsService() {
			return testDetailsService;
		}
		public void setTestDetailsService(TestDetailsService testDetailsService) {
			this.testDetailsService = testDetailsService;
		}
		
		public HosOrderDAO getHosorderDAO() {
			return hosorderDAO;
		}
		public void setHosorderDAO(HosOrderDAO hosorderDAO) {
			this.hosorderDAO = hosorderDAO;
		}
	    
	    

}
