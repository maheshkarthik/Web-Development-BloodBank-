package com.mybank.myapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mybank.myapp.dao.ScheduleDAO;
import com.mybank.myapp.pojo.Donor;
import com.mybank.myapp.pojo.Schedule;

public class ScheduleService {
	ScheduleDAO scheduleDAO;
	
	public ScheduleService()
	{
		
	}
	
	 public void addSchedule(Schedule d){
		 scheduleDAO.addSchedule(d);
	    }
	    public void updateSchedule(Schedule d){
	    	scheduleDAO.updateSchedule(d);
	    }
	    public Schedule getSchedule(long id){
	    	Schedule d = scheduleDAO.getSchedule(id);
	        return d;
	    }
	    public List<Schedule> getScheduleList(){
	        List<Schedule> schedules = scheduleDAO.getScheduleList();
	        List<Schedule> activeschedules = new ArrayList<Schedule>();
	        for(Schedule u: schedules){
	            
	        	activeschedules.add(u);
	            
	        }
	        return activeschedules;
	    }
	    
	    public boolean confirmSchedule(List<Schedule> schedulelist,Schedule schedule)
	    {
	    	for(Schedule s:schedulelist)
	    	{
	    		System.out.println("one");
	    		if(schedule.getOrg().getOrgname().equals(s.getOrg().getOrgname())&& schedule.getScheduletime().equals(s.getScheduletime())&& schedule.getStatus().equals(s.getStatus()))
	    		{
	    			System.out.println("two");
	    			return false;
	    		}
	    	}
	    	return true;
	    }

		public ScheduleDAO getScheduleDAO() {
			return scheduleDAO;
		}

		public void setScheduleDAO(ScheduleDAO scheduleDAO) {
			this.scheduleDAO = scheduleDAO;
		}
	    

}
