package com.mybank.myapp.dao;

import java.util.List;

import com.mybank.myapp.pojo.Donor;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DonorDAO {
	
	 private HibernateTemplate hibernateTemplate;

	    public DonorDAO() {
	    }

	    public Donor getDonor(long id){

	        Donor d = (Donor)hibernateTemplate.get(Donor.class, id);
	        return d;
	    }

	    public List<Donor> getDonorList(){

	        List<Donor> donors = (List<Donor>)hibernateTemplate.loadAll(Donor.class);
	        return donors;
	    }

	    public void addDonor(Donor d){

	        hibernateTemplate.save(d);
	    }

	    public void deleteDonor(Donor d){

	        hibernateTemplate.delete(d);
	    }

	    public void updateDonor(Donor d){

	        hibernateTemplate.update(d);
	    }

	    public HibernateTemplate getHibernateTemplate() {
	        return hibernateTemplate;
	    }

	    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
	        this.hibernateTemplate = hibernateTemplate;
	    }


}
