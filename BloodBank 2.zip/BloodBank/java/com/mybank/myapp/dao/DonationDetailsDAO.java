package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.DonationDetails;

public class DonationDetailsDAO {

	private HibernateTemplate hibernateTemplate;

    public DonationDetailsDAO() {
    }

    public DonationDetails getDonationDetails(long id){

    	DonationDetails d = (DonationDetails)hibernateTemplate.get(DonationDetails.class, id);
        return d;
    }

    public List<DonationDetails> getDonationDetailsList(){

        List<DonationDetails> donationdetails = (List<DonationDetails>)hibernateTemplate.loadAll(DonationDetails.class);
        return donationdetails;
    }

    public void addDonationDetails(DonationDetails d){

        hibernateTemplate.save(d);
    }

    public void deleteDonationDetails(DonationDetails d){

        hibernateTemplate.delete(d);
    }

    public void updateDonationDetails(DonationDetails d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}
