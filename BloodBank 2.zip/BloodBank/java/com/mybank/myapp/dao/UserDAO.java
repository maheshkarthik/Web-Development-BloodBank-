package com.mybank.myapp.dao;

import java.util.List;

import com.mybank.myapp.pojo.User;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class UserDAO {

	private HibernateTemplate hibernateTemplate;

    public UserDAO() {
        //hibernateTemplate = new HibernateTemplate();
    }

    public User getUser(long l){

        User ua = (User)hibernateTemplate.get(User.class, l);
        return ua;
    }

    public List<User> getUserList(){

        List<User> user = (List<User>)hibernateTemplate.loadAll(User.class);
        return user;
    }

    public void addUser(User ua){

        hibernateTemplate.save(ua);
    }

    public void deleteUser(User ua){

        hibernateTemplate.delete(ua);
    }

    public void updateUser(User ua){

        User u = (User)hibernateTemplate.get(User.class, ua.getEmpid());
        u = ua;
        hibernateTemplate.update(u);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }

}

