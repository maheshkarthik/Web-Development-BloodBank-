package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.HosRequest;
import com.mybank.myapp.pojo.Inventory;

public class HosRequestDAO {

	private HibernateTemplate hibernateTemplate;

    public HosRequestDAO() {
    }

    public HosRequest getHosRequest(long id){

    	HosRequest d = (HosRequest)hibernateTemplate.get(HosRequest.class, id);
        return d;
    }

    public List<HosRequest> getHosRequestList(){

        List<HosRequest> HosRequestlist = (List<HosRequest>)hibernateTemplate.loadAll(HosRequest.class);
        return HosRequestlist;
    }

    public void addHosRequest(HosRequest d){

        hibernateTemplate.save(d);
    }

    public void deleteHosRequest(HosRequest d){

        hibernateTemplate.delete(d);
    }

    public void updateHosRequest(HosRequest d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}



