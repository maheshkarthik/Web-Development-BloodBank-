package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.Inventory;

public class InventoryDAO {
	

	private HibernateTemplate hibernateTemplate;

    public InventoryDAO() {
    }

    public Inventory getInventory(long id){

    	Inventory d = (Inventory)hibernateTemplate.get(Inventory.class, id);
        return d;
    }

    public List<Inventory> getInventoryList(){

        List<Inventory> inventorylist = (List<Inventory>)hibernateTemplate.loadAll(Inventory.class);
        return inventorylist;
    }

    public void addInventory(Inventory d){

        hibernateTemplate.save(d);
    }

    public void deleteInventory(Inventory d){

        hibernateTemplate.delete(d);
    }

    public void updateInventory(Inventory d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}


