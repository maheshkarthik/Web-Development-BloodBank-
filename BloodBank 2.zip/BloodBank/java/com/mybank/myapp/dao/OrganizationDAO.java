package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.Organization;;

public class OrganizationDAO {

	private HibernateTemplate hibernateTemplate;

    public OrganizationDAO() {
    }

    public Organization getOrganization(long l){

    	Organization d = (Organization)hibernateTemplate.get(Organization.class, l);
        return d;
    }

    public List<Organization> getOrganizationList(){

        List<Organization> orgs = (List<Organization>)hibernateTemplate.loadAll(Organization.class);
        return orgs;
    }

    public void addOrganization(Organization d){

        hibernateTemplate.save(d);
    }

    public void deleteOrganization(Organization d){

        hibernateTemplate.delete(d);
    }

    public void updateOrganization(Organization d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}

