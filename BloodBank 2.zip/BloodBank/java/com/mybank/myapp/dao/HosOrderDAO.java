package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.HosOrder;

public class HosOrderDAO {

	private HibernateTemplate hibernateTemplate;

    public HosOrderDAO() {
    }

    public HosOrder getHosOrder(int id){

    	HosOrder d = (HosOrder)hibernateTemplate.get(HosOrder.class, id);
        return d;
    }

    public List<HosOrder> getHosOrderList(){

        List<HosOrder> HosOrderlist = (List<HosOrder>)hibernateTemplate.loadAll(HosOrder.class);
        return HosOrderlist;
    }

    public void addHosOrder(HosOrder d){

        hibernateTemplate.save(d);
    }

    public void deleteHosOrder(HosOrder d){

        hibernateTemplate.delete(d);
    }

    public void updateHosOrder(HosOrder d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}


