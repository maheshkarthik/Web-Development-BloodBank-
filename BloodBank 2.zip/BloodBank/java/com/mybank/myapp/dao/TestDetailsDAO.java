package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.TestDetails;

public class TestDetailsDAO {
	private HibernateTemplate hibernateTemplate;

    public TestDetailsDAO() {
    }

    public TestDetails getTestDetails(long id){

    	TestDetails d = (TestDetails)hibernateTemplate.get(TestDetails.class, id);
        return d;
    }

    public List<TestDetails> getTestDetailsList(){

        List<TestDetails> testdetailslist = (List<TestDetails>)hibernateTemplate.loadAll(TestDetails.class);
        return testdetailslist;
    }

    public void addTestDetails(TestDetails d){

        hibernateTemplate.save(d);
    }

    public void deleteTestDetails(TestDetails d){

        hibernateTemplate.delete(d);
    }

    public void updateTestDetails(TestDetails d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}


