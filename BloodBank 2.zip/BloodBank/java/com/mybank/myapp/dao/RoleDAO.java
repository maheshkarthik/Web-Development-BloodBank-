package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.Role;

public class RoleDAO {

	private HibernateTemplate hibernateTemplate;

    public RoleDAO() {
    }

    public Role getRole(int id){

        Role d = (Role)hibernateTemplate.get(Role.class, id);
        return d;
    }

    public List<Role> getRoleList(){

        List<Role> roles = (List<Role>)hibernateTemplate.loadAll(Role.class);
        return roles;
    }

    public void addRole(Role d){

        hibernateTemplate.save(d);
    }

    public void deleteRole(Role d){

        hibernateTemplate.delete(d);
    }

    public void updateRole(Role d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}
