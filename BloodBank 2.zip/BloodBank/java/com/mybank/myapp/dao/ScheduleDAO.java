package com.mybank.myapp.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.mybank.myapp.pojo.Schedule;;

public class ScheduleDAO {

	private HibernateTemplate hibernateTemplate;

    public ScheduleDAO() {
    }

    public Schedule getSchedule(long id){

    	Schedule d = (Schedule)hibernateTemplate.get(Schedule.class, id);
        return d;
    }

    public List<Schedule> getScheduleList(){

        List<Schedule> schedules = (List<Schedule>)hibernateTemplate.loadAll(Schedule.class);
        return schedules;
    }

    public void addSchedule(Schedule d){

        hibernateTemplate.save(d);
    }

    public void deleteSchedule(Schedule d){

        hibernateTemplate.delete(d);
    }

    public void updateSchedule(Schedule d){

        hibernateTemplate.update(d);
    }

    public HibernateTemplate getHibernateTemplate() {
        return hibernateTemplate;
    }

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }


}

