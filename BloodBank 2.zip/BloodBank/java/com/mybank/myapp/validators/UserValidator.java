package com.mybank.myapp.validators;



import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.mybank.myapp.pojo.User;

public class UserValidator implements Validator {

    public boolean supports(Class aClass)
    {
        return aClass.equals(User.class);
    }

    public void validate(Object obj, Errors errors)
    {
        User newUser = (User) obj;
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstname", "error.invalid.firstname", "First Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastname", "error.invalid.lastname", "Last Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ssn", "error.invalid.ssn", "SSN Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "org", "error.invalid.org", "Organization Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "zipcode", "error.invalid.zipcode", "SSN Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phno", "error.invalid.phno", "PhNo Required");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "error.invalid.user", "User Name Required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.password", "Password Required");
    }
}
