package com.mybank.myapp.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.mybank.myapp.pojo.Donor;


public class DonorValidator implements Validator {

	 public boolean supports(Class aClass)
	    {
	        return aClass.equals(Donor.class);
	    }

	    public void validate(Object obj, Errors errors)
	    {
	        Donor newUser = (Donor) obj;
	        
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstname", "error.invalid.firstname", "First Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastname", "error.invalid.lastname", "Last Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ssn", "error.invalid.ssn", "SSN Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "organization", "error.invalid.organization", "Organization Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "zipcode", "error.invalid.zipcode", "SSN Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dob", "error.invalid.dob", "DOB Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.invalid.email", "Email Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bloodgrp", "error.invalid.bloodgrp", "BloodGroup Required");

	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "error.invalid.user", "User Name Required");
	        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.invalid.password", "Password Required");
	    }
	}
