package com.mybank.myapp.exception;

public class AdException extends Exception
{

	public AdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AdException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AdException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
